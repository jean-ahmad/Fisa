var searchData=
[
  ['newregion',['newRegion',['../classfisa_1_1Machine.html#a0f36d8cc6045fc6dbbf6d678f4f2bd46',1,'fisa::Machine::newRegion()'],['../classfisa_1_1CompositeState.html#acb5edf94f38b067a66dcdcd34dbed5a2',1,'fisa::CompositeState::newRegion()']]]
];
