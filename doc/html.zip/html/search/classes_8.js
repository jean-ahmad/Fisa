var searchData=
[
  ['region',['Region',['../classfisa_1_1Region.html',1,'fisa']]],
  ['regioninfo',['RegionInfo',['../structfisa_1_1RegionInfo.html',1,'fisa']]],
  ['regionscomponent',['RegionsComponent',['../classfisa_1_1RegionsComponent.html',1,'fisa']]]
];
