var searchData=
[
  ['name',['name',['../classfisa_1_1Machine.html#a62ed9d77be9f675be2c1371f0aae1a02',1,'fisa::Machine::name()'],['../classfisa_1_1SimpleState.html#ab6e641622cc52c868fac165dfd6c6d72',1,'fisa::SimpleState::name()'],['../classfisa_1_1Region.html#ab69f50e04f485f7ad750d827b7fdfde3',1,'fisa::Region::name()'],['../classfisa_1_1Transition.html#a3fdc02a4a778da36e243f3e302fceacd',1,'fisa::Transition::name()']]],
  ['newregion',['newRegion',['../classfisa_1_1Machine.html#a0f36d8cc6045fc6dbbf6d678f4f2bd46',1,'fisa::Machine::newRegion()'],['../classfisa_1_1RegionsComponent.html#ac96f0172d5a1cc3268a079ed3366ba86',1,'fisa::RegionsComponent::newRegion()'],['../classfisa_1_1CompositeState.html#acb5edf94f38b067a66dcdcd34dbed5a2',1,'fisa::CompositeState::newRegion()']]],
  ['now',['now',['../classfisa_1_1OpenSourceTime.html#a3996e986d652bcd98ac8ad98762d2900',1,'fisa::OpenSourceTime::now()'],['../classfisa_1_1WindowsTime.html#abfb5eabe19a3b67610181800e510d5a2',1,'fisa::WindowsTime::now()']]]
];
