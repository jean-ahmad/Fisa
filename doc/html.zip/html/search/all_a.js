var searchData=
[
  ['newregion',['newRegion',['../classfisa_1_1Machine.html#a0f36d8cc6045fc6dbbf6d678f4f2bd46',1,'fisa::Machine::newRegion()'],['../classfisa_1_1CompositeState.html#acb5edf94f38b067a66dcdcd34dbed5a2',1,'fisa::CompositeState::newRegion()']]],
  ['now',['now',['../classfisa_1_1OpenSourceTime.html#a3996e986d652bcd98ac8ad98762d2900',1,'fisa::OpenSourceTime::now()'],['../classfisa_1_1WindowsTime.html#abfb5eabe19a3b67610181800e510d5a2',1,'fisa::WindowsTime::now()']]]
];
