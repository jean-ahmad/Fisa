var searchData=
[
  ['documentation_20summary',['Documentation summary',['../index.html',1,'']]]
];
